#include<stdio.h>
#include<string.h>

struct INFO2 {
	int A, B, C, F;
	char name[9];
};

extern "C" void pastedata(INFO2* ss) {
	INFO2* cls = (INFO2*)ss;
	printf_s("�����������ݣ�\n");
	scanf_s("%s", cls->name, 9);
	scanf_s("%d%d%d", &(cls->A), &(cls->B), &(cls->C));
}

extern "C" void exitornot(INFO2* ss, int* n) {
	char ch;
	getchar();
	printf_s("���������ѡ��q/r/m\n");
	scanf_s("%c", &ch, 1);
	switch(ch) {
	case 'q':
		*n = 0;
		break;
	case 'r':
		*n = 1;
		break;
	case 'm':
		pastedata(ss);
		*n = -1;
		break;
	default:
		*n = -1;
		break;
	}
}

extern "C" void printMID(INFO2* ss, int n) {
	n /= 25;
	for (int i = 0; i <= n; i++) {
		printf("SAMID: %s\n", ss[i].name);
		printf("SDA: %d\n", ss[i].A);
		printf("SDB: %d\n", ss[i].B);
		printf("SDC: %d\n", ss[i].C);
		printf("SF: %d\n\n", ss[i].F);
	}
}

extern "C" void compare(char* v1, char* v2, int* n) {
	for (int i = 0; i < 3; i++) {
		printf_s("�������û��������룺\n");
		scanf_s("%s%s", v1, 11, v2, 11);
		int a = strcmp(v1, "caijizhou");
		int b = strcmp(v2, "bestfriend");
		if (a == 0 && b == 0) {
			*n = 1;
			return;
		}
		printf_s("�û��������������\n");
	}
	*n = 0;
}